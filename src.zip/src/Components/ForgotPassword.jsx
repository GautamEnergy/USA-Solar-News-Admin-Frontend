import React from 'react'

const ForgotPassword = () => {
  return (
  <>
    
  </>
  )
}

export default ForgotPassword
